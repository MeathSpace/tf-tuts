def lambda_handler(event, context):

    response = {
        statusCode : 200,
        body : "Perfect Response"

    }
    return response